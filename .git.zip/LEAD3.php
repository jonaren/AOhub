
    <style>
        /* PASTE YOUR EXTERNAL CSS HERE - This will override everything */
        /* 
        Copy and paste your CSS classes from your external stylesheet here
        to ensure they load properly with the video library
        */
        
        .fa-chevron-left:not(.nav-link), .fa-chevron-right:not(.nav-link) {
            font-size: 12px !important;
        }
        
        .video-library-container {
            background: #61769c;
            padding: 2rem ;
        }
        
        .category-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 2px solid rgba(255,255,255,0.3);
            margin: 0.25rem;
            padding: 0.75rem 1.5rem;
            border-radius: 25px;
            transition: all 0.3s ease;
        }
        
        .category-btn:hover, .category-btn.active {
            background: rgba(255,255,255,0.9);
            color: #61769c;
            border-color: white;
        }
        
        .video-section {
            display: none;
            opacity: 0;
            transition: opacity 0.3s ease;
            padding: 2rem 0;
        }
        
        .video-section.active {
            display: block;
            opacity: 1;
        }
        
        .category-title {
            color: white;
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .video-carousel {
            background: rgba(255,255,255,0.95);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .carousel-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .carousel-btn {
            background: #61769c;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .carousel-btn:hover:not(:disabled) {
            background: #4a5a7a;
            transform: translateY(-2px);
        }
        
        .carousel-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        
        .video-counter {
            font-weight: bold;
            color: #61769c;
        }
        
        .progress-indicator {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }
        
        .progress-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #ddd;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .progress-dot.active {
            background: #61769c;
            transform: scale(1.2);
        }
        
        .video-info {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        
        .video-title {
            color: #61769c;
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
        }
        
        .video-description {
            color: #666;
            margin-bottom: 0;
        }
        
        .video-container {
            position: relative;
            width: 100%;
            height: 0;
            padding-bottom: 56.25%;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .video-container iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: none;
        }
        
        .loading-message {
            text-align: center;
            color: white;
            font-size: 1.2rem;
            margin: 2rem 0;
        }
        
        .error-message {
            text-align: center;
            color: #ff6b6b;
            background: rgba(255,255,255,0.9);
            padding: 1rem;
            border-radius: 10px;
            margin: 1rem;
        }
        
        .config-section {
            display: none;
        }
        
        .config-input {
            display: none;
        }
        
        .config-btn {
            display: none;
        }
    </style>

    <div class="container-fluid" style="padding: 0px" id="LEAD">
        <div class="video-library-container">
            <div class="row justify-content-center">
                <div class="col-12">
                    <h1 class="text-center text-white my-5">
                        LEAD Learning Video Library
                    </h1>
                </div>
            </div>

            <div id="loadingMessage" class="loading-message">
                <i class="fas fa-spinner fa-spin"></i> Loading videos...
            </div>

            <div id="errorMessage" class="error-message" style="display: none;"></div>

            <div class="row justify-content-center category-buttons" id="categoryButtons" style="display: none;">
                <div class="col-12 text-center" id="categoryButtonsContainer">
                    <!-- Category buttons will be generated dynamically -->
                </div>
            </div>

            <!-- Video sections will be generated dynamically -->
            <div id="videoSections"></div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/PapaParse/5.4.1/papaparse.min.js"></script>
    <script>
        let videoData = {};
        let currentVideoIndex = {};

        // Convert Google Sheets URL to CSV export URL
        function convertToCSVUrl(sheetUrl) {
            // If it's already a published CSV URL, use it directly
            if (sheetUrl.includes('pub?output=csv') || sheetUrl.includes('export?format=csv')) {
                return sheetUrl;
            }
            
            // Extract the sheet ID from various Google Sheets URL formats
            let sheetId = '';
            
            if (sheetUrl.includes('/spreadsheets/d/')) {
                const match = sheetUrl.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
                if (match) sheetId = match[1];
            }
            
            if (!sheetId) {
                throw new Error('Invalid Google Sheets URL. Please make sure you\'re using a valid Google Sheets link.');
            }
            
            // Return CSV export URL
            return `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv`;
        }

        // Load data from Google Sheets automatically
        async function loadFromGoogleSheets() {
            // Add cache busting to prevent stale data
            const sheetUrl = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vRuCWi1oN5MxulX4MCXW0wQWOsvFuoMn8yn0J2FzjoBro0115ydjiJ4ZHY29VuFBnH2f732Ytx8uNFr/pub?output=csv&bust=' + Date.now();

            try {
                showLoading(true);
                hideError();
                
                const response = await fetch(sheetUrl, {
                    method: 'GET',
                    headers: {
                        'Accept': 'text/csv, text/plain, */*'
                    },
                    cache: 'no-cache'
                });
                
                if (!response.ok) {
                    throw new Error(`Failed to fetch data: ${response.status} ${response.statusText}`);
                }
                
                const csvText = await response.text();
                
                // Use Papa Parse for better CSV parsing
                const parsed = Papa.parse(csvText, {
                    header: true,
                    dynamicTyping: true,
                    skipEmptyLines: true
                });
                const data = parsed.data;
                
                // Debug logging - remove these after testing
                console.log('Parsed data:', data);
                console.log('Total rows:', data.length);
                console.log('Last 3 rows:', data.slice(-3));
                
                videoData = processVideoData(data);
                
                // Debug processed categories
                console.log('Processed categories:', Object.keys(videoData));
                
                initializeVideoLibrary();
                
                showLoading(false);
                
                // Add class to body to indicate video library is loaded
                document.body.classList.add('video-library-loaded');
                
                // Trigger custom event for external CSS
                setTimeout(() => {
                    if (typeof window !== 'undefined') {
                        window.dispatchEvent(new CustomEvent('videoLibraryReady', {
                            detail: { categories: Object.keys(videoData) }
                        }));
                    }
                }, 200);
                
            } catch (error) {
                showLoading(false);
                showError(`Error loading data: ${error.message}`);
                console.error('Error:', error);
            }
        }

        // Process CSV data into video structure
        function processVideoData(data) {
            const processedData = {};
            
            data.forEach(row => {
                const originalCategory = row.category || 'uncategorized';
                // Create a safe category ID for CSS selectors
                const safeCategoryId = originalCategory.toLowerCase()
                    .replace(/\s+/g, '-')           // Replace spaces with hyphens
                    .replace(/[^a-z0-9\-]/g, '')    // Remove special characters
                    .replace(/\-+/g, '-')           // Replace multiple hyphens with single
                    .replace(/^\-|\-$/g, '');       // Remove leading/trailing hyphens
                
                if (!processedData[safeCategoryId]) {
                    processedData[safeCategoryId] = {
                        displayName: originalCategory,
                        videos: []
                    };
                }
                
                processedData[safeCategoryId].videos.push({
                    id: row.video_url || row.id || '',
                    title: row.title || 'Untitled',
                    description: row.description || ''
                });
            });
            
            return processedData;
        }

        // Initialize the video library interface
        function initializeVideoLibrary() {
            const categories = Object.keys(videoData);
            
            if (categories.length === 0) {
                showError('No video categories found in the data');
                return;
            }
            
            // Generate category buttons
            generateCategoryButtons(categories);
            
            // Generate video sections
            generateVideoSections(categories);
            
            // Initialize current video index for each category
            categories.forEach(category => {
                currentVideoIndex[category] = 0;
            });
            
            // Show the interface
            document.getElementById('categoryButtons').style.display = 'block';
            
            // Force reload external CSS after dynamic content is loaded
            forceReloadExternalCSS();
            
            // Auto-select first category
            setTimeout(() => {
                const firstBtn = document.querySelector('.category-btn');
                if (firstBtn) {
                    firstBtn.click();
                }
            }, 100);
        }
        
        // Force reload and apply external CSS after dynamic content loads
        function forceReloadExternalCSS() {
            // Method 1: Trigger CSS recalculation (safe method)
            try {
                document.body.style.display = 'none';
                document.body.offsetHeight; // Force reflow
                document.body.style.display = '';
            } catch(e) {
                console.log('CSS reflow method skipped');
            }
            
            // Method 2: Fire custom event for CSS reapplication
            try {
                if (typeof window !== 'undefined') {
                    window.dispatchEvent(new Event('videoLibraryLoaded'));
                }
            } catch(e) {
                console.log('Custom event skipped');
            }
            
            console.log('External CSS reload triggered after video library initialization');
        }

        // Generate category buttons dynamically
        function generateCategoryButtons(categories) {
            const container = document.getElementById('categoryButtonsContainer');
            container.innerHTML = '';
            
            categories.forEach(categoryId => {
                const categoryData = videoData[categoryId];
                const button = document.createElement('button');
                button.className = 'btn category-btn';
                button.setAttribute('data-category', categoryId);
                button.textContent = categoryData.displayName;
                
                button.addEventListener('click', function() {
                    const selectedCategory = this.dataset.category;
                    showCategory(selectedCategory);
                    
                    // Update button states
                    document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                });
                
                container.appendChild(button);
            });
        }

        // Format category name for display
        function formatCategoryName(category) {
            return category
                .replace(/([A-Z])/g, ' $1')
                .replace(/^./, str => str.toUpperCase())
                .trim();
        }

        // Generate video sections dynamically
        function generateVideoSections(categories) {
            const container = document.getElementById('videoSections');
            container.innerHTML = '';
            
            categories.forEach(category => {
                const section = createVideoSection(category);
                container.appendChild(section);
            });
        }

        // Create a video section element
        function createVideoSection(categoryId) {
            const categoryData = videoData[categoryId];
            const section = document.createElement('div');
            section.className = 'video-section';
            section.id = categoryId;
            
            section.innerHTML = `
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-10 col-12">
                        <h2 class="category-title">${categoryData.displayName}</h2>
                        <div class="video-carousel">
                            <div class="carousel-controls">
                                <button class="carousel-btn" id="prevBtn-${categoryId}" disabled>
                                    <i class="fas fa-chevron-left"></i> Previous
                                </button>
                                <div class="video-counter">
                                    <span id="currentVideo-${categoryId}">1</span> of <span id="totalVideos-${categoryId}">0</span>
                                </div>
                                <button class="carousel-btn" id="nextBtn-${categoryId}">
                                    Next <i class="fas fa-chevron-right"></i>
                                </button>
                            </div>
                            
                            <div class="progress-indicator" id="progress-${categoryId}"></div>
                            
                            <div class="video-info">
                                <h3 class="video-title" id="videoTitle-${categoryId}">Loading...</h3>
                                <p class="video-description" id="videoDesc-${categoryId}">Loading video information...</p>
                            </div>
                            
                            <div class="video-container">
                                <iframe id="videoFrame-${categoryId}" src="" allowfullscreen></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            return section;
        }

        function showCategory(category) {
            // Hide all video sections
            document.querySelectorAll('.video-section').forEach(section => {
                section.classList.remove('active');
            });
            
            // Show selected category with animation delay
            setTimeout(() => {
                document.getElementById(category).classList.add('active');
                initializeCategory(category);
            }, 200);
        }

        function initializeCategory(category) {
            const categoryData = videoData[category];
            const videos = categoryData ? categoryData.videos : [];
            const totalVideos = videos.length;
            
            if (totalVideos === 0) {
                showError(`No videos found for category: ${categoryData.displayName}`);
                return;
            }
            
            // Initialize current video index for this category
            currentVideoIndex[category] = 0;
            
            // Update total video count
            const totalElement = document.getElementById(`totalVideos-${category}`);
            if (totalElement) {
                totalElement.textContent = totalVideos;
            }
            
            // Create progress dots
            createProgressDots(category, totalVideos);
            
            // Load first video
            loadVideo(category, 0);
            
            // Setup navigation buttons - do this after loading the video
            setTimeout(() => {
                setupNavigation(category);
            }, 100);
        }

        function createProgressDots(category, count) {
            const progressContainer = document.getElementById(`progress-${category}`);
            if (!progressContainer) return;
            
            progressContainer.innerHTML = '';
            
            for (let i = 0; i < count; i++) {
                const dot = document.createElement('div');
                dot.className = 'progress-dot';
                if (i === 0) dot.classList.add('active');
                
                // Use closure to capture the correct index
                dot.addEventListener('click', (function(index) {
                    return function() {
                        loadVideo(category, index);
                    };
                })(i));
                
                progressContainer.appendChild(dot);
            }
        }

        function setupNavigation(category) {            
            const prevBtn = document.getElementById(`prevBtn-${category}`);
            const nextBtn = document.getElementById(`nextBtn-${category}`);
            
            if (!prevBtn || !nextBtn) {
                return;
            }
            
            // Clear any existing event handlers
            prevBtn.onclick = null;
            nextBtn.onclick = null;
            
            // Set up new event handlers with proper error handling
            prevBtn.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                if (!this.disabled) {
                    navigateVideo(category, -1);
                }
                return false;
            };
            
            nextBtn.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                if (!this.disabled) {
                    navigateVideo(category, 1);
                }
                return false;
            };
        }

        function navigateVideo(category, direction) {
            const categoryData = videoData[category];
            const videos = categoryData ? categoryData.videos : [];
            const currentIndex = currentVideoIndex[category] || 0;
            const newIndex = currentIndex + direction;
            
            // Check bounds
            if (newIndex < 0 || newIndex >= videos.length) {
                return; // Don't navigate if out of bounds
            }
            
            loadVideo(category, newIndex);
        }

        function loadVideo(category, index) {
            const categoryData = videoData[category];
            const videos = categoryData ? categoryData.videos : [];
            const video = videos[index];
            
            if (!video) return;
            
            currentVideoIndex[category] = index;
            
            // Update video frame
            const videoFrame = document.getElementById(`videoFrame-${category}`);
            if (videoFrame) {
                videoFrame.src = video.id;
            }
            
            // Update video info
            const titleElement = document.getElementById(`videoTitle-${category}`);
            const descElement = document.getElementById(`videoDesc-${category}`);
            const currentElement = document.getElementById(`currentVideo-${category}`);
            
            if (titleElement) titleElement.textContent = video.title;
            if (descElement) {
                if (video.description.includes('<a')) {
                    descElement.innerHTML = video.description;
                } else {
                    descElement.textContent = video.description;
                }
            }
            if (currentElement) currentElement.textContent = index + 1;
            
            // Update progress dots
            const progressDots = document.querySelectorAll(`#progress-${category} .progress-dot`);
            progressDots.forEach((dot, i) => {
                dot.classList.toggle('active', i === index);
            });
            
            // Update navigation buttons state
            updateNavigationButtons(category, index, videos.length);
        }
        
        function updateNavigationButtons(category, currentIndex, totalVideos) {
            const prevBtn = document.getElementById(`prevBtn-${category}`);
            const nextBtn = document.getElementById(`nextBtn-${category}`);
            
            if (prevBtn && nextBtn) {
                const isFirstVideo = currentIndex === 0;
                const isLastVideo = currentIndex === totalVideos - 1;
                
                prevBtn.disabled = isFirstVideo;
                nextBtn.disabled = isLastVideo;
                
                // Update button styling based on disabled state
                if (isFirstVideo) {
                    prevBtn.style.opacity = '0.5';
                    prevBtn.style.cursor = 'not-allowed';
                } else {
                    prevBtn.style.opacity = '1';
                    prevBtn.style.cursor = 'pointer';
                }
                
                if (isLastVideo) {
                    nextBtn.style.opacity = '0.5';
                    nextBtn.style.cursor = 'not-allowed';
                } else {
                    nextBtn.style.opacity = '1';
                    nextBtn.style.cursor = 'pointer';
                }
            }
        }

        // Utility functions
        function showLoading(show) {
            document.getElementById('loadingMessage').style.display = show ? 'block' : 'none';
        }

        function showError(message) {
            const errorDiv = document.getElementById('errorMessage');
            errorDiv.textContent = message;
            errorDiv.style.display = 'block';
        }

        function hideError() {
            document.getElementById('errorMessage').style.display = 'none';
        }

        // Load your data on page load
        document.addEventListener('DOMContentLoaded', function() {
            // Auto-load the data from Google Sheets
            loadFromGoogleSheets();
        });
    </script>

<link rel="stylesheet" href="/css/main.css">
