<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AOhub.org</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <link href="css/main.css" rel="stylesheet" >
    <link rel="apple-touch-icon" sizes="180x180" href="/images/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/images/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/images/favicon-16x16.png">
<link rel="manifest" href="/site.webmanifest">
</head>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6E8LS11HGL"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-6E8LS11HGL');
</script>
<body>

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top">
  <div class="container-fluid">
   <a class="navbar-brand" href="/index">
      <img src="https://snippets.usnsandbox.net/images/shield.png" alt="" width="41" height="46" style="margin-right:5px;"><strong>Advisory Organizations Hub</strong>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
         <li class="nav-item"><a class="nav-link" href="/index.html#intro">Intro</a></li>
         <li class="nav-item"><a class="nav-link" href="/index.html#LEAD">Lead Learning</a></li>
         <li class="nav-item"><a class="nav-link" href="/index.html#resources">Resources</a></li>
        <li class="nav-item"><a class="nav-link" href="/index.html#soe">Standards of Excellence</a></li>
        
      </ul>
         <button class="btn btn-outline-primary btn-sm my-2 my-sm-0" href="https://mysaboard.org">mysaboard.org <i class="fa-solid fa-square-arrow-up-right"></i></button>
    </div>
  </div>
</nav>
